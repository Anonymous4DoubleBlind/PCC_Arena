
# How to generate the per-data point config files

Run the `../scripts/gen-cfg.sh` from within the cfg directory:

```
 $ ../scripts/gen-cfg.sh [--octree|--trisoup] [--raht|--pred-lift]
```
